package com.zy.kotlinday1.day3

import android.content.Context

/**
 *@author:zhangyue
 *@date:2020/10/14
 */
class Tiger(context: Context,name:String,sex:Int) : Animal1(context,name,sex) {

    override fun testMethod2(){

    }
}