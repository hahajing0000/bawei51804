package com.zy.kotlinday1.day4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.zy.kotlinday1.R
import kotlinx.android.synthetic.main.activity_day4_3.*
import kotlinx.android.synthetic.main.item_layout.view.*

class Day4_3Activity : AppCompatActivity() {

    var mDataSource:MutableList<String>?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_day4_3)

        mDataSource= mutableListOf()
        for (item in 1..100){
            mDataSource?.add(item.toString())
        }

        val adapter:DemoAdapter= DemoAdapter(mDataSource!!)

        rv_main.layoutManager=LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false)
        rv_main.adapter=adapter
        rv_main.itemAnimator=DefaultItemAnimator()
        rv_main.addItemDecoration(DividerItemDecoration(this,DividerItemDecoration.VERTICAL))

    }

    class DemoAdapter(private val dataSource:List<String>):RecyclerView.Adapter<DemoAdapter.DemoViewHolder>(){
        class DemoViewHolder(item: View):RecyclerView.ViewHolder(item){
            val tv_content:TextView=item.tv_item_content
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DemoViewHolder {
            val inflate =
                LayoutInflater.from(parent.context).inflate(R.layout.item_layout, parent, false)
            return DemoViewHolder(inflate)
        }

        override fun getItemCount(): Int {
            return dataSource.size
        }

        override fun onBindViewHolder(holder: DemoViewHolder, position: Int) {
            val value = dataSource.get(position)
            holder.tv_content.text=value
        }
    }
}