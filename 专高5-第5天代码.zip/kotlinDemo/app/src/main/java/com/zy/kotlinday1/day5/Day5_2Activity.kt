package com.zy.kotlinday1.day5

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.zy.kotlinday1.R
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

class Day5_2Activity : AppCompatActivity() {

    var name:String by PropDelegte("","")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_day5_2)

        name=""
        Log.d("123","${name}")

        //let run with also apply
//        val withDemo:WithDemo= WithDemo("小红",20)
//        withDemo.method1()
//        withDemo.method2()
//
//        with(withDemo){
//            method1()
//            method2()
//        }
//
//        val let = withDemo.let {
//            it.method1()
//            1L
//        }
//
//        val run = withDemo.run {
//            this.method1()
//            1
//        }
//
//        val apply = withDemo.apply {
//            this.method1()
//        }
//
//        val also = withDemo.also {
//            it.method1()
//        }
    }

    class PropDelegte<T>(var key:String,var value:T):ReadWriteProperty<Any?,T>{
        override fun getValue(thisRef: Any?, property: KProperty<*>): T {
            Log.d("123","get value")
            return value
        }

        override fun setValue(thisRef: Any?, property: KProperty<*>, value: T) {
            Log.d("123","set value")
        }

    }
}
