package com.zy.kotlinday1.day2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.zy.kotlinday1.R
import kotlinx.android.synthetic.main.activity_day2.*
import kotlinx.android.synthetic.main.activity_main.*

class Day2Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_day2)

        btn_day2_Test.setOnClickListener { v->

            //跳出多重循环
//            out@for(i in 1..100){
//                Log.d("123","for 1 i-> ${i}")
//                for (j in 1..100){
//                    Log.d("123","for 2 j-> ${j}")
//                    break@out
//                }
//            }

//            val a:String? = null
//            Log.d("123","?. -》 ${a?.length?:10}")
//            Log.d("123","?. -》 ${a!!.length}")

            //is in 比较
//             val intArray:IntArray = intArrayOf(0,1,2,3,4,5)
//            //in intarray
//            if (4 is Int){
//                 Log.d("123","1")
//             }
//            else{
//                 Log.d("123","-1")
//             }

//            Log.d("123","method called -> ${testMethod1("11","22")}")
//            Log.d("123","method called -> ${testMethod1("11",b="",c="33")}")

//            varargMethod("123","234","345","456")

//            testMethod<Float>(1.0F,1.2F)
//
//            val intArrays:Array<Int> = arrayOf(0,1,2)
////            setArrayNumber(intArrays)
//            setArrayStr<Int>(intArrays)

//            val result:Boolean=testGJ({
//                    a,b-> a>b
//            })
//
//            if (result){
//                Log.d("123","true")
//            }
//            else{
//                Log.d("123","false")
//            }

//            val result1=testGJ(10,20,{a,b->a+b})
//            val result2=testGJ(10,20,{a,b->a-b})
//            val result3=testGJ(10,20,{a,b->a*b})
//            val result4=testGJ(10,20,{a,b->a/b})
//
//            val arrayInt:Array<Int> = arrayOf(1,2,3,4)
//            arrayInt.zhangsan(1,2,{a,b->a+b})

//            TestClass().test()
        }
    }

    /**
     * 高阶函数
     */
    fun testGJ(a:Int,b:Int,greater:(Int,Int)->Int):Int{
        return greater(a,b)
    }

    fun testGJ2(a:Int,b:Int,greater2:(Int,Int)->Unit){
        greater2(a,b)
    }

//    /**
//     * 扩展函数
//     */
//    fun Array<Int>.zhangsan(pos1: Int, pos2: Int) {
//        val tmp = this[pos1] //thisᤒᐏහᕟᛔ᫝
//        this[pos1] = this[pos2]
//        this[pos2] = tmp
//    }

    /**
     * 扩展函数
     */
    fun Array<Int>.zhangsan(pos1: Int, pos2: Int,js:(Int,Int)->Int) {
        val tmp = this[pos1] //thisᤒᐏහᕟᛔ᫝
        this[pos1] = this[pos2]
        this[pos2] = tmp
        js(pos1,pos2)
    }


//    /**
//     * kotlin 函数demo1
//     */
//    fun testMethod1(a:String,b:String?="bbcc",c:String):String{
//        return a+b+c
//    }

//    /**
//     * 可变参数列表demo
//     */
//    fun varargMethod(vararg args:String){
//        for (item in args){
//            Log.d("123","arg -> ${item}")
//        }
//    }

    /**
     * 泛型方法
     */
    fun <R> testMethod(vararg args:R?){
        for (item in args){
            Log.d("123","value -> ${item.toString()}")
        }
    }

    fun setArrayNumber(array:Array<Number>) {
        var str:String = "111"
        for (item in array) {
            str = str + item.toString() + ", "
        }
        tv_content.text = str
    }

    /**
     * 内联函数
     */
    inline fun <reified T : Number> setArrayStr(array:Array<T>) {
        var str:String = "111"
        for (item in array) {
            str = str + item.toString() + ", "
        }
        tv_content.text = str
    }

    /**
     * 简化函数
     */
    fun testMax(a:Int,b:Int):Boolean=if(a>b) true else false


}