package com.zy.kotlinday1.day4

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.CalendarContract
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import com.zy.kotlinday1.R
import kotlinx.android.synthetic.main.activity_day4_1.*
import org.jetbrains.anko.selector
import org.jetbrains.anko.toast

class Day4_1Activity : AppCompatActivity() {

    lateinit var name:String
    val age:Int by lazy {
        10
    }

    override fun attachBaseContext(newBase: Context?) {
        super.attachBaseContext(newBase)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_day4_1)


        tb_day4_test.title = "我是主标题"

        tb_day4_test.setTitleTextColor(Color.RED)

        tb_day4_test.setLogo(R.mipmap.ic_launcher)

        tb_day4_test.subtitle = "我是子标题"

        tb_day4_test.setSubtitleTextColor(Color.YELLOW)

        tb_day4_test.setBackgroundResource(R.drawable.ic_launcher_background)

        setSupportActionBar(tb_day4_test)

        tb_day4_test.setNavigationIcon(R.drawable.ic_launcher_background)

//        btn_day4_1_goto.setOnClickListener { v->
//            val intent = Intent(this, Day4_2Activity::class.java)
//            intent.putExtra("data",UserBean("小明",20))
//            startActivity(intent)
//        }
//
//        val satellites = listOf("金星","木星","水星")
//        tv_day4_1_spinner.text = satellites[0]
//        tv_day4_1_spinner.setOnClickListener {
//            selector("请选择星星", satellites,{
//                di,i->
//                toast("您选择了：${satellites.get(i)}")
//            })
//        }

        fab_test.setOnClickListener { v->
            Snackbar.make(cl_main,"我是SnackBar",Snackbar.LENGTH_SHORT).show()
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
    }
}