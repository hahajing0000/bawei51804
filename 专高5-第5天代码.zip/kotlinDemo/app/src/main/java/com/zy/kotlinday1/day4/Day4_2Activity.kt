package com.zy.kotlinday1.day4

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.zy.kotlinday1.R

class Day4_2Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_day4_2)

        val parcelableExtra = intent.getParcelableExtra<UserBean>("data")
        if (parcelableExtra==null){
            Toast.makeText(this,"is null",Toast.LENGTH_SHORT).show()
        }else{
            Toast.makeText(this,"data name -> ${parcelableExtra.name}",Toast.LENGTH_SHORT).show()
        }
    }
}