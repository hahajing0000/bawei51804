package com.zy.kotlinday1.day1

import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.annotation.RequiresApi
import com.zy.kotlinday1.R
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {


    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tv_content.setText("11111111111")

        var testArray:Array<Int> = arrayOf(1,2,3,4,5)

        btn_test.setOnClickListener { v: View->
//            val a:Int = 50
//            //类型转换
//            tv_content.setText(a.toString())

//            Log.d("123","array size=>"+testArray.size+" index equals 2=>"+testArray[1]+testArray.get(1))

//            val test:String = "world"
//
//            Log.d("123","hello ${test.toString()}")
//
//            val testList:MutableList<String> = mutableListOf("小明","小红","小绿")
//
//            val testSet:Set<String> = setOf("小红","小红","小绿")
//
//            val testList:MutableList<String> = mutableListOf("11","22","33")
            //for in 遍历
//            for (item in testSet){
//                Log.d("123","name => ${item}")
//            }

            //迭代器遍历
//            var testIterator=testSet.iterator()
//            while (testIterator.hasNext()){
//                var data=testIterator.next()
//                Log.d("123","name => ${data}")
//            }

            //Foreach 方式
//            testSet.forEach { Log.d("123","name => ${it}") }

            //list 测试demo代码
//            testList.add("44")
//            testList.remove("22")

//            通过下标获取指定元素

//            for (i in testList.indices){
//                var item= testList.get(i)
//                Log.d("123","item => ${item}")
//            }

            //Map 的初始化及遍历
//            val testMap:Map<String,String> = mapOf(Pair("11","value1"),Pair("22","value2"))//mapOf("11" to "value1","22" to "value2")
//            for(item in testMap){
//                Log.d("123","key=>${item.key} value=>${item.value}")
//            }
//
//            testMap.forEach { t, u -> Log.d("123","key->${t} value->${u}")  }

//            tv_content.text=if (1==1) "true" else "false"

            //when else语句相当于Java里面的switch case
//            val testFlag:Int = 0
//            when(testFlag){
//                0 -> tv_content.setText("0")
//                1 -> tv_content.setText("1")
//                2 -> tv_content.setText("2")
//                else -> tv_content.setText("other")
//            }

//            tv_content.text=when(testFlag){
//                0->"1"
//                1->"2"
//                else->"other"
//            }

            //is 操作符demo
//            val test:String = "123"
//            tv_content.text=if(test is String) "True" else "False"

            for (i in 50 downTo 10 step 2){
                Log.d("123","value->${i}")
            }

        }

        //变量声明
        var i:String = ""
        // val/var 变量名：变量类型 = 右值
        val n:Int = 10

        //数组定义
        var intArray:IntArray = intArrayOf(10,20,30)

        //字符串数组的创建
        var stringArray:Array<String> = arrayOf("11","22","33")
        var intArray2:Array<Int> = arrayOf(1,2,3)

    }
}