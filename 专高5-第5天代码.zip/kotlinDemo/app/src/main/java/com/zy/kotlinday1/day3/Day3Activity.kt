package com.zy.kotlinday1.day3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.zy.kotlinday1.R
import kotlinx.android.synthetic.main.activity_day3.*

class Day3Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_day3)

        btn_day3_Test.setOnClickListener { v->
            Animal1(this,"",0,10).name=""
            Animal1.prop2=""
        }

        cb_day3_Test.isChecked=true

        cb_day3_Test.setOnCheckedChangeListener { buttonView, isChecked ->
            Toast.makeText(this,"${if(isChecked) "选中" else "未选中"}",Toast.LENGTH_SHORT).show()
        }

//        Cock3(Cock2("")).callOut()

//        Test1Class.Test2Class().test()
    }
}