package com.zy.kotlinday1.day3

/**
 *@author:zhangyue
 *@date:2020/10/14
 */
data class UserBean(val id:Long,var name:String,var age:Int,var address:String) {
}