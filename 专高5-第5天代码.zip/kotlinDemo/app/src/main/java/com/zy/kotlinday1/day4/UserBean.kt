package com.zy.kotlinday1.day4

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 *@author:zhangyue
 *@date:2020/10/15
 */
@Parcelize
class UserBean(var name:String,var age:Int) : Parcelable {
}