package com.zy.kotlinday1.day3

/**
 *@author:zhangyue
 *@date:2020/10/14
 */
enum class Season(val seasonName:String) {

    SPRING("春天"),
    SUMMER("夏天")

}