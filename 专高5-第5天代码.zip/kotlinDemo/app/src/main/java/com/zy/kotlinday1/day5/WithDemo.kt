package com.zy.kotlinday1.day5

/**
 *@author:zhangyue
 *@date:2020/10/16
 */
class WithDemo(var name:String,var age:Int) {
    fun method1():String{
        return name;
    }

    fun method2():Int{
        return age
    }
}