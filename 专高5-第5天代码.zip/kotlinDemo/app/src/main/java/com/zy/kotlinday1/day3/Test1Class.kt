package com.zy.kotlinday1.day3

/**
 *@author:zhangyue
 *@date:2020/10/14
 */
class Test1Class(name:String) {

    val age:Int=10

   inner class Test2Class(){
        val name:String=""
        fun test(){
            Season.SPRING.ordinal

            SeasonSealed.Spring("春天")

            UserBean(1L,"李四",20,"天津")

            TClass<String>("")
        }
    }

}