package com.zy.kotlinday1.day3

/**
 *@author:zhangyue
 *@date:2020/10/14
 */
class Cock(name:String,color:Int,age:Int) : Bird(name,color) {
    override fun callOut() {

    }
}