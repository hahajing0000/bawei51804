package com.zy.usercenter.model.protocol.req

/**
 *@author:zhangyue
 *@date:2020/10/21
 */
data class ReqUserBean(var phoneNumber:String,var pwd:String) {
}