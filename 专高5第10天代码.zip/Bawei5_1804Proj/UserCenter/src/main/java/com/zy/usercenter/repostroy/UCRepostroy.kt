package com.zy.usercenter.repostroy

import com.zy.net.protocol.resp.BaseRespEntity
import com.zy.usercenter.callback.ResultCallback
import com.zy.usercenter.contract.UserCenterContract
import com.zy.usercenter.model.service.UCModel
import com.zy.usercenter.model.protocol.req.ReqUserBean
import com.zy.usercenter.model.protocol.req.UserEntity
import io.reactivex.Observable
import kotlinx.coroutines.Deferred

/**
 *@author:zhangyue
 *@date:2020/10/21
 */
class UCRepostroy: UserCenterContract.UserCenterRepostroy() {
    override fun register(bean: UserEntity): Deferred<BaseRespEntity<UserEntity>> {
        return mModel.register(bean)
    }


    override fun setModel() {
        mModel= UCModel()
    }
}