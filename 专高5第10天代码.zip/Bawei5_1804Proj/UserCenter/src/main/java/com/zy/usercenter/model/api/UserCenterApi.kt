package com.zy.usercenter.model.api

import com.zy.net.protocol.resp.BaseRespEntity
import com.zy.usercenter.model.protocol.req.ReqUserBean
import com.zy.usercenter.model.protocol.req.UserEntity
import io.reactivex.Observable
import kotlinx.coroutines.Deferred
import retrofit2.http.Body
import retrofit2.http.POST

/**
 *@author:zhangyue
 *@date:2020/10/21
 */
interface UserCenterApi {

    @POST("api/User/register")
    fun register(@Body bean: UserEntity):Deferred<BaseRespEntity<UserEntity>>
}