package com.zy.usercenter.presenter

import android.util.Log
import com.zy.net.common.doResult
import com.zy.net.protocol.resp.BaseRespEntity
import com.zy.net.retrofit.BaseObserable
import com.zy.usercenter.callback.ResultCallback
import com.zy.usercenter.contract.UserCenterContract
import com.zy.usercenter.model.protocol.req.ReqUserBean
import com.zy.usercenter.model.protocol.req.UserEntity
import com.zy.usercenter.repostroy.UCRepostroy
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.functions.Consumer
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.*

/**
 *@author:zhangyue
 *@date:2020/10/21
 */
class UCPresenter(mView:UserCenterContract.UserCenterView): UserCenterContract.UserCenterPresenter(mView) {
    override fun register(bean: UserEntity) {

        val async = GlobalScope.launch {
            val result = mRepostroy.register(bean)
                .doResult({
                mView.success()
            },{
                Log.d("123","error info -> ${it.message}")
                mView.failed()
            })
        }


    }


    override fun setRepostroy() {
        mRepostroy=UCRepostroy()
    }


}