package com.zy.usercenter

import com.zy.resource.BaseApp

/**
 *@author:zhangyue
 *@date:2020/10/21
 */
class UserCenterApplication : BaseApp() {

}