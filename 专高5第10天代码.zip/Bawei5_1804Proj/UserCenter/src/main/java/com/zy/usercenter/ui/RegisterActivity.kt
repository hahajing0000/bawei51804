package com.zy.usercenter.ui

import android.os.Handler
import android.os.Looper
import android.util.Log
import com.zy.mvpcore.ui.BaseMVPActivity
import com.zy.net.common.runOnUi
import com.zy.usercenter.R
import com.zy.usercenter.contract.UserCenterContract
import com.zy.usercenter.model.protocol.req.UserEntity
import com.zy.usercenter.presenter.UCPresenter
import kotlinx.android.synthetic.main.activity_register.*

class RegisterActivity : BaseMVPActivity<UCPresenter>(),UserCenterContract.UserCenterView {

    override fun initEvent() {

        btn_usercenter_reg.setOnClickListener {
            mPresenter.register(UserEntity("1990-1-1",0,et_usercenter_pwd.text.toString().trim(),"0",et_usercenter_phonenumber.text.toString().trim()));
        }
    }

    override fun initData() {

    }

    override fun initView() {

    }

    override fun getLayoutId(): Int {
        return R.layout.activity_register
    }

    override fun setPresenter() {
        mPresenter= UCPresenter(this)
    }

    override fun success() {
        Log.d("123",".........")
        this.runOnUi {
            showMsg("Success")
        }
    }

    private val handle:Handler= Handler(Looper.getMainLooper())
    override fun failed() {
        this.runOnUi {
            showMsg("Failed")
        }

    }
}