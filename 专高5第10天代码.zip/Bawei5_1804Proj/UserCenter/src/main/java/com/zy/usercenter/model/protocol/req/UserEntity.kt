package com.zy.usercenter.model.protocol.req

/**
 *@author:zhangyue
 *@date:2020/10/21
 */
data class UserEntity(
    val birthday: String,
    val id: Int,
    val pwd: String,
    val sex: String,
    val username: String
)