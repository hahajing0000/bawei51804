package com.zy.usercenter.callback

/**
 *@author:zhangyue
 *@date:2020/10/21
 */
interface ResultCallback<T> {
    fun onSuccess(result:T);
    fun onFailed(throwable:Throwable);
}