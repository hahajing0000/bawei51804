package com.zy.usercenter.model.service

import android.os.SystemClock
import com.zy.net.RetrofitFactory
import com.zy.net.protocol.resp.BaseRespEntity
import com.zy.usercenter.callback.ResultCallback
import com.zy.usercenter.contract.UserCenterContract
import com.zy.usercenter.model.api.UserCenterApi
import com.zy.usercenter.model.protocol.req.ReqUserBean
import com.zy.usercenter.model.protocol.req.UserEntity
import io.reactivex.Observable
import kotlinx.coroutines.Deferred

/**
 *@author:zhangyue
 *@date:2020/10/21
 */
class UCModel:UserCenterContract.UserCenterModel {
    override fun register(bean: UserEntity): Deferred<BaseRespEntity<UserEntity>> {
        val api = RetrofitFactory.instance.create(UserCenterApi::class.java)
        return api.register(bean)
    }

}