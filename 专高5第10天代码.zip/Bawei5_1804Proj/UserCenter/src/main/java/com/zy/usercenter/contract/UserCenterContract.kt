package com.zy.usercenter.contract

import com.zy.mvpcore.model.IModel
import com.zy.mvpcore.presenter.BasePresenter
import com.zy.mvpcore.repostroy.BaseRepostroy
import com.zy.mvpcore.ui.IView
import com.zy.net.protocol.resp.BaseRespEntity
import com.zy.usercenter.callback.ResultCallback
import com.zy.usercenter.model.protocol.req.ReqUserBean
import com.zy.usercenter.model.protocol.req.UserEntity
import io.reactivex.Observable
import kotlinx.coroutines.Deferred

/**
 *@author:zhangyue
 *@date:2020/10/21
 */
interface UserCenterContract {
    interface UserCenterModel:IModel{
        fun register(bean:UserEntity):Deferred<BaseRespEntity<UserEntity>>
    }

    abstract class UserCenterRepostroy: BaseRepostroy<UserCenterModel>() {
        abstract fun register(bean:UserEntity):Deferred<BaseRespEntity<UserEntity>>
    }

    abstract class UserCenterPresenter(mView:UserCenterView): BasePresenter<UserCenterRepostroy,UserCenterView>(mView) {
        abstract fun register(bean:UserEntity);
    }

    interface UserCenterView:IView{
        fun success()
        fun failed()
    }
}