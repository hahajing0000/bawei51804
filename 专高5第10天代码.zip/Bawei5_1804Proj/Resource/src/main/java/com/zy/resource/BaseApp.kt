package com.zy.resource

import android.app.Application
import android.content.Context

/**
 * @author:zhangyue
 * @date:2020/10/21
 */
open class BaseApp:Application(){

    override fun onCreate() {
        super.onCreate()
        getAppContext(this)
    }

    companion object{
        lateinit var appContext:Context
        fun getAppContext(_context:Context){
            appContext=_context
        }
    }
}