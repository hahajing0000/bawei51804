package com.zy.net.retrofit;

import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.zy.net.protocol.resp.BaseRespEntity;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Converter;

/**
 * @author:zhangyue
 * @date:2020/9/11
 */
public final class CustomGsonResponseBodyConverter<T> implements Converter<ResponseBody, T> {
    private final Gson gson;
    private final TypeAdapter<T> adapter;

    CustomGsonResponseBodyConverter(Gson gson, TypeAdapter<T> adapter) {
        this.gson = gson;
        this.adapter = adapter;
    }

    @Override public T convert(ResponseBody value) throws IOException {

        String string = value.string();

        BaseRespEntity baseEntity=new Gson().fromJson(string,BaseRespEntity.class);
        if (baseEntity!=null&&baseEntity.getCode()==-1){
            return (T) baseEntity;
        }

        return (T) baseEntity;

    }
}

