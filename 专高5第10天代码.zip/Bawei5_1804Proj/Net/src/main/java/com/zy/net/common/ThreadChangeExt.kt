package com.zy.net.common

import android.os.Handler
import android.os.Looper

/**
 *@author:zhangyue
 *@date:2020/10/22
 */

private val handle: Handler = Handler(Looper.getMainLooper())

fun <T> T.runOnUi(method:T.()->Unit){
    handle.post{
        method()
    }
}