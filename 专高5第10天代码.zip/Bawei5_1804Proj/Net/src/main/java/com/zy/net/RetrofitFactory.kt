package com.zy.net

import android.security.KeyChain
import com.jakewharton.retrofit2.adapter.kotlin.coroutines.CoroutineCallAdapterFactory
import com.zy.net.api.TokenApi
import com.zy.net.common.Constant
import com.zy.net.retrofit.CustomGsonConverterFactory
import com.zy.resource.BaseApp
import com.zy.storage.SPUtils
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 *@author:zhangyue
 *@date:2020/10/21
 */
class RetrofitFactory private constructor(){
    val retrofit:Retrofit


    companion object{
        val instance:RetrofitFactory by lazy {
            RetrofitFactory()
        }
    }

    init {
         retrofit = Retrofit.Builder()
             .baseUrl(BuildConfig.BASEURL)
             .addConverterFactory(CustomGsonConverterFactory.create())
             .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
             .addCallAdapterFactory(CoroutineCallAdapterFactory())
             .client(createClient())
             .build()
    }

    private fun createClient(): OkHttpClient {
        return OkHttpClient.Builder()
            .readTimeout(15,TimeUnit.SECONDS)
            .writeTimeout(15,TimeUnit.SECONDS)
            .connectTimeout(15,TimeUnit.SECONDS)
            .addNetworkInterceptor(createLogIntereptor())
            .addInterceptor(createTokenIntereptor())
            .build()
    }

    /**
     * 处理后台Token
     */
    private fun createTokenIntereptor(): Interceptor {
        val interceptor= Interceptor {

//            it.proceed(it.request())
            val request = it.request()
            var response:Response?

            val localToken = SPUtils.get(BaseApp.appContext, Constant.Token_KEY, "") as String
            if (localToken.isNotBlank()){
                response = doRequest(it, createNewRequest(request, localToken))
            }else{
                response = it.proceed(request)
            }
            if (check401(response!!)){
                requestNewToken(chain = it, request = request)
            }else{
               response
            }

//
        }

        return interceptor
    }

    private fun requestNewToken(chain: Interceptor.Chain,request: Request):Response{
        val token = requestToken();
        val response = doRequest(chain, createNewRequest(request, token))
        SPUtils.put(BaseApp.appContext,Constant.Token_KEY,token)
        return response
    }

    private fun doRequest(chain: Interceptor.Chain,request: Request):Response{

        return chain.proceed(request)
    }

    private fun createNewRequest(request:Request,token:String):Request{
        val newBuilder =
            request.newBuilder().addHeader("Authorization", "bearer $token")

        val newRequest = newBuilder.build()
        return newRequest
    }

    private fun requestToken():String {
        val tokenApi = create(TokenApi::class.java)
        val token = tokenApi.getToken("password", BuildConfig.VERIFYCODE, "")
        val result = token!!.execute()
        return result.body()?.getAccess_token()?:""
    }

    private fun check401(response: Response): Boolean {
        if (response.code()==401){
            return true
        }
        return false
    }

    /**
     * 日志拦截器
     */
    private fun createLogIntereptor(): Interceptor {
        var logInterceptor=HttpLoggingInterceptor()
        logInterceptor.level=HttpLoggingInterceptor.Level.BODY
        return logInterceptor
    }

    /**
     * 创建Api 实例
     */
    fun <T> create(service:Class<T>):T{
        return retrofit.create(service)
    }
}