package com.zy.net.common

import com.zy.net.protocol.resp.BaseRespEntity
import kotlinx.coroutines.Deferred

/**
 *@author:zhangyue
 *@date:2020/10/22
 */
suspend fun <T> Deferred<T>.doResult(success:(BaseRespEntity<*>)->Unit, failed:(Throwable)->Unit){
    val result = this.await() as BaseRespEntity<*>
    if (result.code==200){

        success(result)
    }
    else{
        failed(Throwable(result.msg))
    }
}
