package com.zy.net.common

/**
 *@author:zhangyue
 *@date:2020/10/21
 */
class Constant {
    companion object{
        val Token_KEY:String="localtoken"
    }
}