package com.zy.net.protocol.resp

/**
 *@author:zhangyue
 *@date:2020/10/21
 */
data class BaseRespEntity<T>(var code:Int,var data:T,var msg:String) {
}