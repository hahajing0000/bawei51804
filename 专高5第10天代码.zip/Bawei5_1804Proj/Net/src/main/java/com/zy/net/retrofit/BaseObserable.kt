package com.zy.net.retrofit

import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.functions.Consumer
import io.reactivex.schedulers.Schedulers

/**
 *@author:zhangyue
 *@date:2020/10/21
 */
class BaseObserable {
    fun <T> doIt(result:Observable<T>, success: Consumer<T>, failed:Consumer<Throwable>){
        result.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
            .subscribe(success,failed)
    }
}