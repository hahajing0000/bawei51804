package com.zy.mvpcore.ui

import android.os.Bundle
import android.os.PersistableBundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 *@author:zhangyue
 *@date:2020/10/21
 */
abstract class BaseActivity:AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(getLayoutId())
        initView();
        initData();
        initEvent();
    }

    abstract fun initEvent()

    abstract fun initData()

    abstract fun initView()

    abstract fun getLayoutId(): Int

    fun showMsg(msg:String){
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show()
    }

}