package com.zy.mvpcore.repostroy

import com.zy.mvpcore.model.IModel

/**
 *@author:zhangyue
 *@date:2020/10/21
 */
abstract class BaseRepostroy<M:IModel> {
    protected lateinit var mModel:M
    abstract fun setModel()

    init {
        setModel()
    }
}