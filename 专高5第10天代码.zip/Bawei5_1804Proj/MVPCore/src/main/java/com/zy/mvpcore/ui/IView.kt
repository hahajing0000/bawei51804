package com.zy.mvpcore.ui

/**
 *@author:zhangyue
 *@date:2020/10/21
 */
interface IView {
}