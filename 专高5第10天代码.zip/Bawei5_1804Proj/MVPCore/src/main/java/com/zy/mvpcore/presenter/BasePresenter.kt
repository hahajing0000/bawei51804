package com.zy.mvpcore.presenter

import com.zy.mvpcore.repostroy.BaseRepostroy
import com.zy.mvpcore.ui.IView

/**
 *@author:zhangyue
 *@date:2020/10/21q
 */
abstract class BasePresenter<Repostroy:BaseRepostroy<*>,V:IView>(var mView:V) {
    protected lateinit var mRepostroy: Repostroy

    abstract fun setRepostroy();

    init {
        setRepostroy()
    }
}