package com.zy.mvpcore.ui

import com.zy.mvpcore.model.IModel
import com.zy.mvpcore.presenter.BasePresenter
import com.zy.mvpcore.repostroy.BaseRepostroy

/**
 *@author:zhangyue
 *@date:2020/10/21
 */
abstract class BaseMVPActivity<P:BasePresenter<*,*>>:BaseActivity() {
    protected lateinit var mPresenter: P

    abstract fun setPresenter()

    init {
        setPresenter()
    }
}