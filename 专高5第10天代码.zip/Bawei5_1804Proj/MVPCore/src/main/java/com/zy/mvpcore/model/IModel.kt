package com.zy.mvpcore.model

/**
 *@author:zhangyue
 *@date:2020/10/21
 */
interface IModel {
}