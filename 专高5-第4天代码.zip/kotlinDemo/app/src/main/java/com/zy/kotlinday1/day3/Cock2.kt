package com.zy.kotlinday1.day3

/**
 *@author:zhangyue
 *@date:2020/10/14
 */
class Cock2(override var color: String) : IBird {
    override fun callOut() {
        TODO("Not yet implemented")
    }

    override fun eat(): String {
        return super.eat()
    }
}