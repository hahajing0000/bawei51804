package com.zy.kotlinday1.day3

/**
 *@author:zhangyue
 *@date:2020/10/14
 */
interface IBird {
    fun callOut()

    fun eat():String{
        return "接口的 吃 方法";
    }

    var color:String
}