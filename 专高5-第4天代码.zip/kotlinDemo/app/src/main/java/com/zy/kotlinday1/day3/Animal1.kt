package com.zy.kotlinday1.day3

import android.content.Context
import android.util.Log

/**
 *@author:zhangyue
 *@date:2020/10/14
 */
open class Animal1 @JvmOverloads  constructor(context:Context,var name:String,val sex:Int=0) {

    var sexName:String?

    init {
        val result:String=if(sex==0) "母" else "公"
        Log.d("123","sex -> ${result}")

        sexName=null
    }

    constructor(context: Context,name: String,sex: Int,age:Int):this(context,name,sex)

    fun testMethod1(a:String,b:String):String{
        return a+b
    }

    open protected fun testMethod2(){

    }


    companion object Animal1_1{

        val prop1:String="11"
        var prop2:String="22"

        fun staticMethod1(){

        }
    }
}