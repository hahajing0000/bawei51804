package com.zy.kotlinday1.day2

/**
 * @author:zhangyue
 * @date:2020/10/13
 */
object DateUtils2 {
//    @Volatile
//    var instance: DateUtils2? = null
//        get() {
//            if (null == field) {
//                synchronized(DateUtils2::class.java) {
//                    if (null == field) {
//                        field = DateUtils2()
//                    }
//                }
//            }
//            return field
//        }
//        private set
}