package com.zy.kotlinday1.day4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.zy.kotlinday1.R

class Day4_3Activity : AppCompatActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_day4_3)
    }
}