package com.zy.kotlinday1.day3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.zy.kotlinday1.R;

public class Day3JavaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_day3_java);
        String result = new Animal1(this, "").testMethod1("11", "22");

        Animal1.Animal1_1.staticMethod1();
        Animal1.Animal1_1.setProp2("");
        new Cock2("10").callOut();


    }
}