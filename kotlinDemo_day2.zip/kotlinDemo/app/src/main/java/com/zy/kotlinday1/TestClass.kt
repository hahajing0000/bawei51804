package com.zy.kotlinday1

import android.content.Context
import android.os.Bundle
import android.util.Log

/**
 *@author:zhangyue
 *@date:2020/10/13
 */
class TestClass constructor(context: Context,bundle:Bundle){
//    init {
//        Log.d("123","TestClass is init")
//    }
//
//    fun test(){
//        Log.d("123","test method is called...")
//    }
}

//public class TestClass{
//    public TestClass(Context context,Bundle bundle){
//
//    }
//}