package com.zy.kotlinday1.day3

/**
 *@author:zhangyue
 *@date:2020/10/14
 */
abstract class Bird(name:String,color:Int) {
    abstract fun callOut();
}