package com.zy.kotlinday1.day3

/**
 *@author:zhangyue
 *@date:2020/10/14
 */
sealed class SeasonSealed {
    class Spring(val name:String):SeasonSealed()
    class Summer(val name:String):SeasonSealed()
}